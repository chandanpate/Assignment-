﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace server
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var data = new Dictionary<string, Dictionary<string, int>>()
        {
            {"SetA", new Dictionary<string, int>{{"One",1},{"Two",2}}},
            {"SetB", new Dictionary<string, int>{{"Three",3},{"Four",4}}},
            {"SetC", new Dictionary<string, int>{{"Five",5},{"Six",6}}},
            {"SetD", new Dictionary<string, int>{{"Seven",7},{"Eight",8}}},
            {"SetE", new Dictionary<string, int>{{"Nine",9},{"Ten",10}}}
        };

            TcpListener server = new TcpListener(IPAddress.Parse("10.129.67.130"), 4567);
            server.Start();
            Console.WriteLine("Server started. Listening on port 4567...");

            while (true)
            {
                
                TcpClient client = new TcpClient();
                client = server.AcceptTcpClient();
                Console.WriteLine("Client connected.");

                NetworkStream stream = client.GetStream();
                byte[] buffer = new byte[1024];
                int bytesRead = stream.Read(buffer, 0, buffer.Length);
                string received = Encoding.ASCII.GetString(buffer, 0, bytesRead);
                Console.WriteLine($"Received: {received}");

                string response = "";

                try
                {
                    string[] parts = received.Split('-');
                    if (parts.Length == 2)
                    {
                        string mainKey = parts[0];
                        string subKey = parts[1];

                        if (data.ContainsKey(mainKey) && data[mainKey].ContainsKey(subKey))
                        {
                            int repeatCount = data[mainKey][subKey];

                            for (int i = 0; i < repeatCount; i++)
                            {
                                string currentTime = DateTime.Now.ToString("dd-MM-yyyy HH:mm:ss");
                                byte[] dataToSend = Encoding.ASCII.GetBytes(currentTime + "\n");
                                stream.Write(dataToSend, 0, dataToSend.Length);
                                Console.WriteLine($"Sent: {currentTime}");
                                Thread.Sleep(1000);
                            }
                        }
                        else
                        {
                            response = "EMPTY";
                            byte[] dataToSend = Encoding.ASCII.GetBytes(response);
                            stream.Write(dataToSend, 0, dataToSend.Length);
                        }
                    }
                    else
                    {
                        response = "EMPTY";
                        byte[] dataToSend = Encoding.ASCII.GetBytes(response);
                        stream.Write(dataToSend, 0, dataToSend.Length);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                    byte[] dataToSend = Encoding.ASCII.GetBytes("EMPTY");
                    stream.Write(dataToSend, 0, dataToSend.Length);
                }

                client.Close();
                Console.WriteLine("Client disconnected.\n");
            }
        }
    }
}