﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace Client
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                TcpClient client = new TcpClient("10.129.67.130", 4567);
                NetworkStream stream = client.GetStream();

                Console.Write("Enter string (e.g., SetA-Two): ");
                string message = Console.ReadLine();

                byte[] dataToSend = Encoding.ASCII.GetBytes(message);
                stream.Write(dataToSend, 0, dataToSend.Length);

                byte[] buffer = new byte[1024];
                int bytesRead;

                Console.WriteLine("\n--- Response from Server ---");
                while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) > 0)
                {
                    string response = Encoding.ASCII.GetString(buffer, 0, bytesRead);
                    Console.WriteLine(response);
                }

                client.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
        }
    }
}