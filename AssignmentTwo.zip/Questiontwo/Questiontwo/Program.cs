﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace QuestiontwoServer
{
     class Mainprogram
    {
        public class EncryptedServer
        {
            private TcpListener _listener;
            private List<TcpClient> _clients;
            private byte[] _secretKey;
            private bool _isRunning;

            public EncryptedServer(string host, int port)
            {
                IPAddress ipAddress = host == "localhost" ? IPAddress.Loopback : IPAddress.Parse(host);
                _listener = new TcpListener(ipAddress, port);
                _clients = new List<TcpClient>();
            }

            public void SetEncryptionKey(byte[] key)
            {
                if (key.Length != 16 && key.Length != 24 && key.Length != 32)
                {
                    throw new ArgumentException("Key must be 16, 24, or 32 bytes long");
                }
                _secretKey = key;
            }

            private string EncryptMessage(string message)
            {
                using (Aes aes = Aes.Create())
                {
                    aes.Key = _secretKey;
                    aes.GenerateIV();

                    using (var encryptor = aes.CreateEncryptor())
                    {
                        byte[] plainText = Encoding.UTF8.GetBytes(message);
                        byte[] cipherText = encryptor.TransformFinalBlock(plainText, 0, plainText.Length);

                        byte[] result = new byte[aes.IV.Length + cipherText.Length];
                        Buffer.BlockCopy(aes.IV, 0, result, 0, aes.IV.Length);
                        Buffer.BlockCopy(cipherText, 0, result, aes.IV.Length, cipherText.Length);

                        return Convert.ToBase64String(result);
                    }
                }
            }

            private string DecryptMessage(string encryptedMessage)
            {
                try
                {
                    byte[] fullData = Convert.FromBase64String(encryptedMessage);

                    using (Aes aes = Aes.Create())
                    {
                        aes.Key = _secretKey;

                        byte[] iv = new byte[16];
                        byte[] cipherText = new byte[fullData.Length - 16];
                        Buffer.BlockCopy(fullData, 0, iv, 0, 16);
                        Buffer.BlockCopy(fullData, 16, cipherText, 0, fullData.Length - 16);

                        aes.IV = iv;

                        using (var decryptor = aes.CreateDecryptor())
                        {
                            byte[] plainText = decryptor.TransformFinalBlock(cipherText, 0, cipherText.Length);
                            return Encoding.UTF8.GetString(plainText);
                        }
                    }
                }
                catch (Exception ex)
                {
                    return $"Error decrypting message: {ex.Message}";
                }
            }

            private void HandleClient(TcpClient client)
            {
                NetworkStream stream = client.GetStream();
                byte[] buffer = new byte[4096];
                int bytesRead;

                Console.WriteLine($"New connection from {client.Client.RemoteEndPoint}");
                lock (_clients) _clients.Add(client);

                try
                {
                    while ((bytesRead = stream.Read(buffer, 0, buffer.Length)) != 0)
                    {
                        string encryptedData = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                        string decryptedMessage = DecryptMessage(encryptedData);

                        Console.WriteLine($"Received from {client.Client.RemoteEndPoint}: {decryptedMessage}");

                        if (decryptedMessage.ToLower() == "quit")
                            break;

                        string response = $"Server received: {decryptedMessage}";
                        string encryptedResponse = EncryptMessage(response);
                        byte[] responseData = Encoding.UTF8.GetBytes(encryptedResponse);
                        stream.Write(responseData, 0, responseData.Length);
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error handling client {client.Client.RemoteEndPoint}: {ex.Message}");
                }
                finally
                {
                    lock (_clients) _clients.Remove(client);
                    client.Close();
                    Console.WriteLine($"Connection with {client.Client.RemoteEndPoint} closed");
                }
            }

            public void Start()
            {
                if (_secretKey == null)
                {
                    Console.WriteLine("Please set encryption key first!");
                    return;
                }

                try
                {
                    _listener.Start();
                    _isRunning = true;
                    Console.WriteLine($"Encrypted server started on {_listener.LocalEndpoint}");
                    Console.WriteLine("Waiting for connections...");

                    while (_isRunning)
                    {
                        TcpClient client = _listener.AcceptTcpClient();
                        Thread clientThread = new Thread(() => HandleClient(client));
                        clientThread.IsBackground = true;
                        clientThread.Start();
                    }
                }
                catch (SocketException ex)
                {
                    Console.WriteLine($"Socket exception: {ex.Message}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Server error: {ex.Message}");
                }
                finally
                {
                    Stop();
                }
            }

            public void Stop()
            {
                _isRunning = false;
                _listener?.Stop();

                lock (_clients)
                {
                    foreach (var client in _clients)
                    {
                        client.Close();
                    }
                    _clients.Clear();
                }
                Console.WriteLine("Server stopped");
            }
        }

        class Program
        {
            static void Main(string[] args)
            {
                Console.Write("Enter server host (default: localhost): ");
                string host = Console.ReadLine();
                if (string.IsNullOrEmpty(host)) host = "localhost";

                Console.Write("Enter server port (default: 12345): ");
                string portInput = Console.ReadLine();
                int port = string.IsNullOrEmpty(portInput) ? 12345 : int.Parse(portInput);

                byte[] key;
                while (true)
                {
                    Console.Write("Enter encryption key (16, 24, or 32 characters): ");
                    string keyInput = Console.ReadLine();

                    if (keyInput.Length == 16 || keyInput.Length == 24 || keyInput.Length == 32)
                    {
                        key = Encoding.UTF8.GetBytes(keyInput);
                        break;
                    }
                    Console.WriteLine("Key must be exactly 16, 24, or 32 characters long!");
                }

                EncryptedServer server = new EncryptedServer(host, port);
                server.SetEncryptionKey(key);

                Console.CancelKeyPress += (sender, e) =>
                {
                    e.Cancel = true;
                    server.Stop();
                };

                server.Start();
            }
        }
    }
}