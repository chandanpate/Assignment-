﻿using System;
using System.Net.Sockets;
using System.Text;
using System.Security.Cryptography;

namespace QuestionTwoClient
{
    public class EncryptedClient
    {
        private TcpClient _client;
        private NetworkStream _stream;
        private byte[] _secretKey;

        public void SetEncryptionKey(byte[] key)
        {
            if (key.Length != 16 && key.Length != 24 && key.Length != 32)
            {
                throw new ArgumentException("Key must be 16, 24, or 32 bytes long");
            }
            _secretKey = key;
        }

        private string EncryptMessage(string message)
        {
            using (Aes aes = Aes.Create())
            {
                aes.Key = _secretKey;
                aes.GenerateIV();

                using (var encryptor = aes.CreateEncryptor())
                {
                    byte[] plainText = Encoding.UTF8.GetBytes(message);
                    byte[] cipherText = encryptor.TransformFinalBlock(plainText, 0, plainText.Length);

                    byte[] result = new byte[aes.IV.Length + cipherText.Length];
                    Buffer.BlockCopy(aes.IV, 0, result, 0, aes.IV.Length);
                    Buffer.BlockCopy(cipherText, 0, result, aes.IV.Length, cipherText.Length);

                    return Convert.ToBase64String(result);
                }
            }
        }

        private string DecryptMessage(string encryptedMessage)
        {
            try
            {
                byte[] fullData = Convert.FromBase64String(encryptedMessage);

                using (Aes aes = Aes.Create())
                {
                    aes.Key = _secretKey;

                    byte[] iv = new byte[16];
                    byte[] cipherText = new byte[fullData.Length - 16];
                    Buffer.BlockCopy(fullData, 0, iv, 0, 16);
                    Buffer.BlockCopy(fullData, 16, cipherText, 0, fullData.Length - 16);

                    aes.IV = iv;

                    using (var decryptor = aes.CreateDecryptor())
                    {
                        byte[] plainText = decryptor.TransformFinalBlock(cipherText, 0, cipherText.Length);
                        return Encoding.UTF8.GetString(plainText);
                    }
                }
            }
            catch (Exception ex)
            {
                return $"Error decrypting message: {ex.Message}";
            }
        }

        public bool ConnectToServer(string host, int port)
        {
            try
            {
                _client = new TcpClient();
                _client.Connect(host, port);
                _stream = _client.GetStream();
                Console.WriteLine($"Connected to server at {host}:{port}");
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to connect to server: {ex.Message}");
                return false;
            }
        }

        public string SendMessage(string message)
        {
            try
            {
                string encryptedMessage = EncryptMessage(message);
                byte[] data = Encoding.UTF8.GetBytes(encryptedMessage);
                _stream.Write(data, 0, data.Length);

                byte[] buffer = new byte[4096];
                int bytesRead = _stream.Read(buffer, 0, buffer.Length);
                string encryptedResponse = Encoding.UTF8.GetString(buffer, 0, bytesRead);

                
                return DecryptMessage(encryptedResponse);
            }
            catch (Exception ex)
            {
                return $"Error communicating with server: {ex.Message}";
            }
        }

        public void StartCommunication()
        {
            Console.WriteLine("Type 'quit' to exit the client");

            try
            {
                while (true)
                {
                    Console.Write("Enter message: ");
                    string message = Console.ReadLine();

                    if (string.IsNullOrEmpty(message))
                        continue;

                    string response = SendMessage(message);
                    Console.WriteLine($"Server response: {response}");

                    if (message.ToLower() == "quit")
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Client error: {ex.Message}");
            }
            finally
            {
                _stream?.Close();
                _client?.Close();
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter server host (default: localhost): ");
            string host = Console.ReadLine();
            if (string.IsNullOrEmpty(host)) host = "localhost";

            Console.Write("Enter server port (default: 12345): ");
            string portInput = Console.ReadLine();
            int port = string.IsNullOrEmpty(portInput) ? 12345 : int.Parse(portInput);

            byte[] key;
            while (true)
            {
                Console.Write("Enter encryption key (16, 24, or 32 characters): ");
                string keyInput = Console.ReadLine();

                if (keyInput.Length == 16 || keyInput.Length == 24 || keyInput.Length == 32)
                {
                    key = Encoding.UTF8.GetBytes(keyInput);
                    break;
                }
                Console.WriteLine("Key must be exactly 16, 24, or 32 characters long!");
            }

            EncryptedClient client = new EncryptedClient();
            client.SetEncryptionKey(key);

            if (client.ConnectToServer(host, port))
            {
                client.StartCommunication();
            }
        }
    }
}